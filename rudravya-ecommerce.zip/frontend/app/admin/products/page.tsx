import ProductAdmin from "./product-admin";
export default function Page(){ return <ProductAdmin/> }
